struct Circle
{
	int x;
	int y; 
	int r;
};